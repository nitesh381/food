import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Food App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final List<Restaurant> _restaurants = [
    Restaurant(
      name: 'Burger King',
      imageUrl: 'https://example.com/burger-king.jpg',
      rating: 4.5,
    ),
    Restaurant(
      name: 'McDonalds',
      imageUrl: 'https://example.com/mcdonalds.jpg',
      rating: 4.2,
    ),
    Restaurant(
      name: 'Taco Bell',
      imageUrl: 'https://example.com/taco-bell.jpg',
      rating: 4.7,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Popular Restaurants'),
      ),
      body: ListView.builder(
        itemCount: _restaurants.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Image.network(_restaurants[index].imageUrl),
            title: Text(_restaurants[index].name),
            subtitle: Text('Rating: ${_restaurants[index].rating}'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      RestaurantDetailsScreen(restaurant: _restaurants[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class RestaurantDetailsScreen extends StatelessWidget {
  final Restaurant restaurant;

  const RestaurantDetailsScreen({Key? key, required this.restaurant})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<MenuItems> _menuItems = [
      MenuItems(
          name: 'Cheeseburger',
          description: 'A delicious cheeseburger',
          price: 5.99),
      MenuItems(name: 'Fries', description: 'Golden fries', price: 2.99),
      MenuItems(name: 'Soda', description: 'Cold soda', price: 1.99),
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text(restaurant.name),
      ),
      body: ListView.builder(
        itemCount: _menuItems.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.fastfood),
            title: Text(_menuItems[index].name),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_menuItems[index].description),
                Text('Price: \$${_menuItems[index].price}'),
              ],
            ),
          );
        },
      ),
    );
  }
}

class Restaurant {
  final String name;
  final String imageUrl;
  final double rating;

  Restaurant(
      {required this.name, required this.imageUrl, required this.rating});
}

class MenuItems {
  final String name;
  final String description;
  final double price;

  MenuItems(
      {required this.name, required this.description, required this.price});
}
