package com.example.first

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
